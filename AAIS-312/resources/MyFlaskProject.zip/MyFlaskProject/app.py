from flask import Flask, render_template, request
from transformers import pipeline

app = Flask(__name__)

# Create a translation pipeline
translator = pipeline("translation_en_to_fr", model="Helsinki-NLP/opus-mt-en-fr")

# Translate a sentence
result = translator("I was in the gym and then I went home.")
print("French:", result[0]['translation_text'])


@app.route("/", methods=["GET", "POST"])
def index():
    translated_text = ""
    if request.method == "POST":
        # english_text will contain the value from the textbox 
        english_text = request.form["english_text"]
        # translator is translating from eng to fr 
        result = translator(english_text)
        # result = [{"translation_text": "some french text"}]
        translated_text = result[0]["translation_text"]
    return render_template("index.html", translated_text=translated_text)


if __name__ == "__main__":
    app.run(debug=True)