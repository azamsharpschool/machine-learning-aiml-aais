from flask import Flask, render_template, request, url_for
import numpy as np 
import tensorflow as tf
from keras.applications.resnet50 import ResNet50, preprocess_input, decode_predictions
from keras.preprocessing import image
import os, uuid 

# Create the Flask app
app = Flask(__name__)

model = ResNet50(weights="imagenet")

@app.route("/") 
def index(): 
    return render_template("index.html")

# Save uploads into /static
app.config["UPLOAD_FOLDER"] = os.path.join(app.root_path, "static")


@app.route("/upload", methods=["POST"])
def upload():
    file = request.files["file"]

    # generate unique name
    ext = file.filename.rsplit(".", 1)[-1]  # get extension
    filename = f"{uuid.uuid4().hex}.{ext}"

    path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(path)

    image_url = url_for("static", filename=filename)
    image_path = os.path.join(app.static_folder, filename)
    img = image.load_img(image_path, target_size=(224, 224))
    img_array = image.img_to_array(img)
    x = np.expand_dims(img_array, axis=0)
    # apply preprocessing tailored for ResNet50
    x = preprocess_input(x)
    # make a prediction
    preds = model.predict(x)
    top3 = decode_predictions(preds, top=3)[0]
    return render_template("index.html", image_url=image_url, predictions=top3)

"""
# Define a simple route
@app.route("/")
def home():
    image_path = os.path.join(app.static_folder, "cat.png")
    img = image.load_img(image_path, target_size=(224, 224))
    img_array = image.img_to_array(img)
    x = np.expand_dims(img_array, axis=0)
    # apply preprocessing tailored for ResNet50
    x = preprocess_input(x)
    # make a prediction
    preds = model.predict(x)
    top3 = decode_predictions(preds, top=3)[0]
    print(top3) 
    return "Hello, Flask! 🚀"
"""

# Only run if script is executed directly
if __name__ == "__main__":
    app.run(debug=True)