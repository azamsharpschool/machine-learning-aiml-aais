//
//  SummarizationAppApp.swift
//  SummarizationApp
//
//  Created by Mohammad Azam on 8/20/24.
//

import SwiftUI

@main
struct SummarizationAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
